source("connection_to_datasets/init_all_datasets.R")
.test_param <- function(connection)
{
  ds.share.param(connection)
}