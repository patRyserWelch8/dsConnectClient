#-------------------------------------------------------------------------------
# Copyright (c) 2019 University of Newcastle upon Tyne. All rights reserved.
#
# This program and the accompanying materials
# are made available under the terms of the GNU Public License v3.0.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.
#-------------------------------------------------------------------------------
#
# Datashield test suite set up
#

library(DSI)
library(DSOpal)
library(testthat)
library(httr)
library(dsBaseClient)

print(1)
ds.test_env <- new.env()
print(2)
source("connection_to_datasets/login_details.R")
source("connection_to_datasets/init_all_datasets.R")
print(3)
#ds.test_env <- new.env()
#options(datashield.env=ds.test_env)
print(4)
options(show.error.messages = TRUE)

print("setup - Check connections and server functions")
ls(pattern="ds")
print(5)

connections <- connect.all.datasets()

server.functions <- c("existsDS","removeDS","assignCoordinatesDS",
                      "assignDataDS", "assignParamSettingsDS",
                      "getDataDS", "getCoordinatesDS",
                      "assignSharingSettingsDS", "decryptDataDS",
                      "encryptDataDS", "decryptParamDS",
                      "encryptParamDS", "removeEncryptingDataDS")

aggregate.functions <- datashield.methods(connections,type="aggregate")

print(6)
if(all(server.functions %in% aggregate.functions[,"name"]))
{ 
  print("All the functions have been uploaded on the server")
}

print("setup finished")